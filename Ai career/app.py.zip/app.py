from flask import Flask, render_template, request, redirect
import sqlite3
import os
from PyPDF2 import PdfReader
from flask import session, redirect, url_for
from flask import *
from flask import redirect, url_for
from reportlab.platypus import SimpleDocTemplate, Paragraph
from reportlab.lib.styles import getSampleStyleSheet

app = Flask(__name__)
app.secret_key = "devesh123"

app.config['UPLOAD_FOLDER'] = 'Uploads'

# Home Page
@app.route('/')
def home():
    return render_template('index.html')


# Register Page
@app.route('/register', methods=['GET', 'POST'])
def register():

    if request.method == 'POST':

        name = request.form['name']
        email = request.form['email']
        branch = request.form['branch']
        skills = request.form['skills']
        password = request.form['password']

        conn = sqlite3.connect('database.db')
        cursor = conn.cursor()

        cursor.execute(
            "INSERT INTO students(name,email,branch,skills,password) VALUES(?,?,?,?,?)",
            (name, email, branch, skills, password)
        )

        conn.commit()
        conn.close()

        return "Registration Successful"

    return render_template('register.html')


# Login Page
@app.route('/login', methods=['GET', 'POST'])
def login():

    if request.method == 'POST':

        email = request.form['email']
        password = request.form['password']

        conn = sqlite3.connect('database.db')
        cursor = conn.cursor()

        cursor.execute(
            "SELECT * FROM students WHERE email=? AND password=?",
            (email, password)
        )

        user = cursor.fetchone()

        conn.close()

        if user:
            session['user_id'] = user[0]
            session['name'] = user[1]
            session['branch'] = user[3]
            session['skills'] = user[4]
            return redirect(url_for('dashboard'))
        else:
            return "Invalid Email or Password"

    return render_template('login.html')
    # deshbord
@app.route('/dashboard')
def dashboard():

    if 'user_id' not in session:
        return redirect(url_for('login'))

    return render_template(
        'dashboard.html',
        name=session['name'],
        branch=session['branch'],
        skills=session['skills']
    )
    
@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))
# profileSS
@app.route('/profile')
def profile():

    if 'user_id' not in session:
        return redirect(url_for('login'))

    return render_template(
        'profile.html',
        name=session['name'],
        branch=session['branch'],
        skills=session['skills']
    )
# Resume History Pag
@app.route('/history')
def history():

    if 'user_id' not in session:
        return redirect(url_for('login'))

    conn = sqlite3.connect("database.db")
    cursor = conn.cursor()

    cursor.execute("""
        SELECT filename, score, skills, date
        FROM resume_history
        WHERE user_id=?
        ORDER BY id DESC
    """, (session['user_id'],))

    history = cursor.fetchall()

    conn.close()

    return render_template(
        "history.html",
        history=history
    )   
    
# Career Prediction
@app.route('/career/<skills>')
def career(skills):

    skills = skills.lower()

    if "machine learning" in skills or "ml" in skills:
        result = "Machine Learning Engineer"

    elif "python" in skills:
        result = "Data Scientist"

    elif "html" in skills or "css" in skills or "javascript" in skills:
        result = "Web Developer"

    elif "networking" in skills:
        result = "Cyber Security Analyst"

    else:
        result = "Software Developer"

    return render_template(
        'career.html',
        career=result
    )


# Resume Analyzer
@app.route('/resume', methods=['GET', 'POST'])
def resume():

    if request.method == 'POST':

        file = request.files['resume']

        filepath = os.path.join(
            app.config['UPLOAD_FOLDER'],
            file.filename
        )

        file.save(filepath)

        reader = PdfReader(filepath)

        text = ""

        for page in reader.pages:
            text += page.extract_text() or ""
            print("===== EXTRACTED TEXT =====")
            print(text)
            print("==========================")

        score = 0
        suggestions = []
        if "github" not in text.lower():
            suggestions.append("Add your GitHub profile.")

        if "linkedin" not in text.lower():
            suggestions.append("Add your LinkedIn profile.")

        if "internship" not in text.lower():
            suggestions.append("Mention internship experience.")

        if "project" not in text.lower():
            suggestions.append("Add at least 2 projects.")

        if "achievement" not in text.lower():
            suggestions.append("Include achievements and certifications.")
        detected_skills = []

        if "python" in text.lower():
            score += 20
            detected_skills.append("Python")

        if "java" in text.lower():
            score += 20
            detected_skills.append("Java")

        if "skill" in text.lower() or "skills" in text.lower():
            score += 20
            detected_skills.append("Technical Skills")

        if "project" in text.lower() or "projects" in text.lower():
            score += 20
            detected_skills.append("Projects")

        if "internship" in text.lower():
            score += 20
            detected_skills.append("Internship")

        if score < 60:
            suggestions.append("Add more projects")
            suggestions.append("Add technical skills")
            suggestions.append("Add internship experience")

            # add kiya hai
            conn = sqlite3.connect("database.db")
            cursor = conn.cursor()

            cursor.execute("""
            INSERT INTO resume_history (user_id, filename, score, skills)
            VALUES (?, ?, ?, ?)
            """, (
                session["user_id"],
                file.filename,
                score,
                ", ".join(detected_skills)
            ))

            conn.commit()
            conn.close()

        return render_template(
            'result.html',
            score=score,
            suggestions=suggestions,
            skill =detected_skills
        )

    return render_template('resume.html')
@app.route('/skill-gap', methods=['GET', 'POST'])
def skill_gap():

    if request.method == 'POST':

        career = request.form['career']

        skills = request.form['skills'].lower()

        missing = []

        if career == "Machine Learning Engineer":

            required = [
                "python",
                "tensorflow",
                "pandas",
                "numpy",
                "statistics"
            ]

        elif career == "Web Developer":

            required = [
                "html",
                "css",
                "javascript",
                "react"
            ]

        else:

            required = [
                "networking",
                "linux",
                "ethical hacking"
            ]

        for skill in required:

            if skill not in skills:
                missing.append(skill)

        return render_template(
            'skill_result.html',
            career=career,
            missing=missing
        )

    return render_template('skill_gap.html')
@app.route('/roadmap', methods=['GET', 'POST'])
def roadmap():

    if request.method == 'POST':

        career = request.form['career']

        if career == "Machine Learning Engineer":

            roadmap = [
                "Learn Python",
                "Learn NumPy & Pandas",
                "Learn Statistics",
                "Learn Machine Learning",
                "Learn Deep Learning",
                "Build Projects"
            ]

        elif career == "Web Developer":

            roadmap = [
                "Learn HTML",
                "Learn CSS",
                "Learn JavaScript",
                "Learn React",
                "Learn Backend Development",
                "Build Projects"
            ]

        else:

            roadmap = [
                "Learn Networking",
                "Learn Linux",
                "Learn Cyber Security Basics",
                "Learn Ethical Hacking",
                "Practice Labs"
            ]

        return render_template(
            'roadmap_result.html',
            career=career,
            roadmap=roadmap
        )

    return render_template('roadmap.html')

@app.route('/chatbot', methods=['GET', 'POST'])
def chatbot():

    answer = ""

    if request.method == 'POST':

        question = request.form['question'].lower()

        if "python" in question:
            answer = "Python is useful for AI, Data Science, Web Development and Automation."

        elif "machine learning" in question:
            answer = "Machine Learning Engineers build intelligent systems using Python, TensorFlow and Data Science."

        elif "web developer" in question:
            answer = "Learn HTML, CSS, JavaScript, React and Backend Development."

        elif "cyber security" in question:
            answer = "Learn Networking, Linux, Security Concepts and Ethical Hacking."

        else:
            answer = "Please ask about careers, skills, technologies or learning roadmaps."

    return render_template(
        'chatbot.html',
        answer=answer
    )

    # career_predict
def calculate_match(user_skills, required_skills):

    matched = 0

    for skill in required_skills:
        if skill in user_skills:
            matched += 1

    score = int((matched / len(required_skills)) * 100)

    return score
    # Career Database

CAREERS = {
        "Machine Learning Engineer": {
            "salary": "₹8 - ₹25 LPA",
            "companies": ["Google", "Microsoft", "Amazon", "NVIDIA"],
            "certifications": [
                "Google ML",
                "IBM AI",
                "AWS ML"
           
            ]
        
        },

        "Full Stack Developer": {
            "salary": "₹5 - ₹18 LPA",
            "companies": ["TCS", "Infosys", "Accenture", "Zoho"],
            "certifications": [
                "Meta Frontend",
                "JavaScript",
                "React"
            ]
        },

        "Cyber Security Analyst": {
            "salary": "₹6 - ₹20 LPA",
            "companies": ["Cisco", "IBM", "Wipro", "Deloitte"],
            "certifications": [
                "CEH",
                "CompTIA Security+",
                "CISSP"
            ]
        },

        "Software Developer": {
            "salary": "₹4 - ₹15 LPA",
            "companies": ["Infosys", "TCS", "Capgemini", "HCL"],
            "certifications": [
                "Python",
                "Java",
                "DSA"
            ]
        }
    }       
@app.route('/career-predict', methods=['GET', 'POST'])

def career_predict():

    if request.method == "POST":

        skills = request.form.get("skills", "").lower()
        interest = request.form.get("interest", "").lower()

        career = ""
        missing_skills = []
        top_careers = []
        match_score = 0
        reason = []
        roadmap = []


        if "python" in skills and "ai" in interest:

            required = [
                "python",
                "numpy",
                "pandas",
                "machine learning",
                "sql",
                "git"
            ]

            match_score = calculate_match(skills, required)

            career = "🤖 Machine Learning Engineer"

            reason = [
                "Python detected",
                "AI interest matched"
            ]

            roadmap = [
                "Learn NumPy",
                "Learn Pandas",
                "Machine Learning",
                "Deep Learning",
                "Build AI Projects"
            ]

            missing_skills = []

            for skill in required:
                if skill not in skills:
                    missing_skills.append(skill.title())

        elif "html" in skills or "javascript" in skills:

            required = [
                "html",
                "css",
                "javascript",
                "react",
                "git"
            ]

            match_score = calculate_match(skills, required)

            career = "🌐 Full Stack Developer"

            missing_skills = []

            for skill in required:
                if skill not in skills:
                    missing_skills.append(skill.title())


        elif "security" in interest:

            required = [
                "networking",
                "linux",
                "python",
                "wireshark",
                "ethical hacking"
            ]

            match_score = calculate_match(skills, required)

            career = "🔐 Cyber Security Analyst"

            missing_skills = []

            for skill in required:
                if skill not in skills:
                    missing_skills.append(skill.title())

        else:

            required = [
                "python",
                "sql",
                "git"
            ]

            match_score = calculate_match(skills, required)

            career = "💻 Software Developer"

            missing_skills = []

            for skill in required:
                if skill not in skills:
                    missing_skills.append(skill.title())
                    

       # print("Career:", career)
        #print("Career Info:", CAREERS.get(career))
        return render_template(
            "career_predict.html",
            career=career,
            reason=reason,
            roadmap=roadmap,
            match_score=match_score,
            top_careers=top_careers,
            missing_skills=missing_skills,
            career_info = CAREERS.get(career)
            
            
        )

    return render_template("career_predict.html")
    
# @app.route('/logout')
##def logout():
#S    return redirect('/login') 

from flask import send_file

@app.route('/download-report')
def download_report():

    doc = SimpleDocTemplate("Career_Report.pdf")

    styles = getSampleStyleSheet()

    story = []

    story.append(Paragraph("AI Powered Smart Career Guidance System", styles['Title']))

    story.append(Paragraph("<br/>", styles['Normal']))

    story.append(Paragraph("Student Career Report", styles['Heading2']))

    story.append(Paragraph("Name : Devesh Gupta", styles['Normal']))

    story.append(Paragraph("Recommended Career : Machine Learning Engineer", styles['Normal']))

    story.append(Paragraph("Resume Score : 80 / 100", styles['Normal']))

    story.append(Paragraph("Generated by Flask Project", styles['Normal']))

    doc.build(story)

    return send_file(
        "Career_Report.pdf",
        as_attachment=True
    )
if __name__ == '__main__':
    app.run(debug=True)